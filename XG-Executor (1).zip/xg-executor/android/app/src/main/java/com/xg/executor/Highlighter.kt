package com.xg.executor

import android.graphics.Color
import android.text.Editable
import android.text.Spanned
import android.text.style.ForegroundColorSpan

/** Lightweight regex syntax highlighter for Python and Lua. */
object Highlighter {
    class Hl(color: Int) : ForegroundColorSpan(color)

    private const val KEYWORD = 0xFF60A5FA.toInt()
    private const val STRING = 0xFFFBBF24.toInt()
    private const val NUMBER = 0xFFC084FC.toInt()
    private const val COMMENT = 0xFF64748B.toInt()
    private const val BUILTIN = 0xFF22D3EE.toInt()

    private val pyKeywords = Regex("\\b(and|as|assert|async|await|break|class|continue|def|del|elif|else|except|finally|for|from|global|if|import|in|is|lambda|nonlocal|not|or|pass|raise|return|try|while|with|yield|None|True|False)\\b")
    private val luaKeywords = Regex("\\b(and|break|do|else|elseif|end|false|for|function|goto|if|in|local|nil|not|or|repeat|return|then|true|until|while)\\b")
    private val builtins = Regex("\\b(print|len|range|open|input|str|int|float|list|dict|set|tuple|type|require|pairs|ipairs|tostring|tonumber|xg)\\b")
    private val number = Regex("\\b\\d+(\\.\\d+)?\\b")
    private val strings = Regex("\"\"\"[\\s\\S]*?\"\"\"|'''[\\s\\S]*?'''|\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*'")
    private val pyComment = Regex("#[^\\n]*")
    private val luaComment = Regex("--[^\\n]*")

    fun apply(e: Editable, lua: Boolean) {
        if (e.length > 60_000) return
        for (s in e.getSpans(0, e.length, Hl::class.java)) e.removeSpan(s)
        val text = e.toString()
        fun paint(r: Regex, color: Int) {
            for (m in r.findAll(text)) e.setSpan(Hl(color), m.range.first, m.range.last + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        paint(builtins, BUILTIN)
        paint(if (lua) luaKeywords else pyKeywords, KEYWORD)
        paint(number, NUMBER)
        paint(strings, STRING)
        paint(if (lua) luaComment else pyComment, COMMENT)
    }
}
