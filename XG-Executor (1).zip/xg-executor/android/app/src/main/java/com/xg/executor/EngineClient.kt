package com.xg.executor

import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket

class EngineException(message: String) : IOException(message)

/**
 * Talks to the Termux engine: one JSON request per line over loopback TCP,
 * every request carries the shared secret token. Blocking: call from a worker thread.
 */
class EngineClient(private val prefs: Prefs) {

    fun call(op: String, vararg params: Pair<String, Any?>): JSONObject {
        if (prefs.token.isEmpty()) throw EngineException("No token configured (run 'xg token' in Termux)")
        Socket().use { s ->
            s.connect(InetSocketAddress("127.0.0.1", prefs.port), 2000)
            s.soTimeout = 6000
            val req = JSONObject().put("op", op).put("token", prefs.token)
            for ((k, v) in params) req.put(k, v)
            val out = s.getOutputStream()
            out.write((req.toString() + "\n").toByteArray(Charsets.UTF_8))
            out.flush()
            val line = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8)).readLine()
                ?: throw EngineException("Engine closed the connection")
            val res = JSONObject(line)
            if (!res.optBoolean("ok", false)) throw EngineException(res.optString("error", "unknown error"))
            return res
        }
    }
}
