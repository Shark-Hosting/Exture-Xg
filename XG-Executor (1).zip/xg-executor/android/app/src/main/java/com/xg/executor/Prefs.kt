package com.xg.executor

import android.content.Context

/** Connection settings. The host is always 127.0.0.1 (not configurable on purpose). */
class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("xg", Context.MODE_PRIVATE)

    var port: Int
        get() = sp.getInt("port", 47821)
        set(v) = sp.edit().putInt("port", v).apply()

    var token: String
        get() = sp.getString("token", "") ?: ""
        set(v) = sp.edit().putString("token", v.trim()).apply()

    var background: Boolean
        get() = sp.getBoolean("background", true)
        set(v) = sp.edit().putBoolean("background", v).apply()

    var lastCode: String
        get() = sp.getString("lastCode", "") ?: ""
        set(v) = sp.edit().putString("lastCode", v).apply()
}
