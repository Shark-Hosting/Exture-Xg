package com.xg.executor

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

/** Setup screen: permissions, connection to the Termux engine, and launching the floating panel. */
class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var portField: EditText
    private lateinit var tokenField: EditText
    private lateinit var connStatus: TextView
    private lateinit var overlayStatus: TextView
    private lateinit var notifStatus: TextView
    private lateinit var a11yStatus: TextView
    private lateinit var battStatus: TextView

    private val bg = 0xFF0B1226.toInt()
    private val card = 0xFF111B38.toInt()
    private val cyan = 0xFF22D3EE.toInt()
    private val muted = 0xFF94A3B8.toInt()
    private val fgText = 0xFFE2E8F0.toInt()
    private val ok = 0xFF22C55E.toInt()
    private val bad = 0xFFEF4444.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rr(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(bg)
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        root.addView(TextView(this).apply {
            text = "XG EXECUTOR"; setTextColor(cyan); textSize = 24f
            setTypeface(typeface, Typeface.BOLD); letterSpacing = 0.12f
        })
        root.addView(label("Floating Python / Lua executor. Scripts run in Termux with Termux's permissions.", muted, 12f))

        // 1. permissions
        root.addView(section("1 · Permissions"))
        overlayStatus = statusLine(); root.addView(overlayStatus)
        root.addView(btn("Grant: Display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        notifStatus = statusLine(); root.addView(notifStatus)
        root.addView(btn("Grant: Notifications") {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            else toast("Notifications are allowed by default on this Android version")
        })
        a11yStatus = statusLine(); root.addView(a11yStatus)
        root.addView(btn("Optional: enable Accessibility (xg.android.* APIs)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        battStatus = statusLine(); root.addView(battStatus)
        root.addView(btn("Battery settings (exempt XG Executor and Termux)") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        // 2. connection
        root.addView(section("2 · Termux engine connection"))
        root.addView(label("Host is fixed to 127.0.0.1. In Termux run:  xg token  then paste it here.", muted, 12f))
        portField = field("Port", prefs.port.toString(), false); portField.inputType = InputType.TYPE_CLASS_NUMBER
        root.addView(portField)
        tokenField = field("Token", prefs.token, true); root.addView(tokenField)
        root.addView(btn("Paste token from clipboard") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()?.trim()
            if (t.isNullOrEmpty()) toast("Clipboard is empty") else tokenField.setText(t)
        })
        root.addView(btn("Save & test connection") { saveAndTest() })
        connStatus = label("Not tested yet", muted, 12f); root.addView(connStatus)

        // 3. run
        root.addView(section("3 · Run"))
        root.addView(btn("Start engine via Termux (needs allow-external-apps)") { startEngineViaTermux() })
        root.addView(btn("Open Termux") {
            val i = packageManager.getLaunchIntentForPackage("com.termux")
            if (i != null) startActivity(i) else toast("Termux is not installed")
        })
        root.addView(btn("LAUNCH FLOATING PANEL", cyan, bg) { launchPanel() })
        root.addView(btn("Stop panel service") {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_QUIT))
        })

        setContentView(ScrollView(this).apply { setBackgroundColor(bg); addView(root) })
    }

    override fun onResume() { super.onResume(); refreshStatus() }

    private fun refreshStatus() {
        fun set(t: TextView, good: Boolean, goodText: String, badText: String) {
            t.text = (if (good) "● " else "○ ") + (if (good) goodText else badText)
            t.setTextColor(if (good) ok else bad)
        }
        set(overlayStatus, Settings.canDrawOverlays(this), "Overlay permission granted", "Overlay permission missing (required)")
        val notif = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
        set(notifStatus, notif, "Notifications allowed", "Notifications not allowed (needed for script notifications)")
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        val me = ComponentName(this, XgAccessibilityService::class.java).flattenToString()
        set(a11yStatus, enabled.contains(me), "Accessibility service enabled", "Accessibility off (only needed for xg.android.*)")
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        set(battStatus, pm.isIgnoringBatteryOptimizations(packageName), "XG exempt from battery optimization", "XG is battery-optimized (recommended: exempt)")
    }

    private fun saveAndTest() {
        val port = portField.text.toString().toIntOrNull()
        if (port == null || port !in 1024..65535) { toast("Port must be 1024-65535"); return }
        prefs.port = port; prefs.token = tokenField.text.toString()
        connStatus.setTextColor(muted); connStatus.text = "Testing…"
        Thread {
            val msg: String; val good: Boolean
            try {
                val r: JSONObject = EngineClient(prefs).call("ping")
                good = true
                msg = "Connected: engine ${r.optString("version")}, Python ${r.optString("python")}, " +
                    "Lua ${if (r.optBoolean("lua")) "available" else "MISSING (pkg install lua54)"}, " +
                    "${r.optInt("running")} job(s) running"
            } catch (e: Exception) {
                good = false
                msg = "Failed: ${e.message}. Is the engine running? (Termux: xg start)"
            }
            runOnUiThread { connStatus.text = msg; connStatus.setTextColor(if (good) ok else bad) }
        }.start()
    }

    private fun startEngineViaTermux() {
        try {
            val i = Intent().setClassName("com.termux", "com.termux.app.RunCommandService")
                .setAction("com.termux.RUN_COMMAND")
                .putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/xg")
                .putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("start"))
                .putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
            startService(i)
            toast("Start command sent to Termux. Press 'Save & test connection' in a few seconds.")
        } catch (e: SecurityException) {
            toast("Not permitted. Grant 'Run commands in Termux' to XG and set allow-external-apps=true in Termux (see README), or run 'xg start' manually.")
        } catch (e: Exception) {
            toast("Could not reach Termux: ${e.message}")
        }
    }

    private fun launchPanel() {
        if (!Settings.canDrawOverlays(this)) { toast("Grant the overlay permission first"); return }
        if (prefs.token.isEmpty()) { toast("Set the token first (Termux: xg token)"); return }
        startForegroundService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_SHOW))
        moveTaskToBack(true)
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    // ---- tiny view helpers
    private fun label(t: String, color: Int, size: Float) = TextView(this).apply {
        this.text = t; setTextColor(color); textSize = size; setPadding(0, dp(4), 0, dp(4))
    }

    private fun section(t: String) = TextView(this).apply {
        this.text = t; setTextColor(cyan); textSize = 14f; setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(22), 0, dp(6))
    }

    private fun statusLine() = TextView(this).apply { textSize = 13f; setPadding(dp(2), dp(8), 0, dp(2)) }

    private fun field(hint: String, value: String, mono: Boolean) = EditText(this).apply {
        this.hint = hint; setText(value); setTextColor(fgText); setHintTextColor(muted); setSingleLine(true)
        if (mono) typeface = Typeface.MONOSPACE
        background = rr(card, 10); setPadding(dp(12), dp(10), dp(12), dp(10))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
    }

    private fun btn(t: String, color: Int = card, fg: Int = fgText, onClick: () -> Unit) = TextView(this).apply {
        this.text = t; setTextColor(fg); textSize = 13f; setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER; setPadding(dp(12), dp(12), dp(12), dp(12))
        background = rr(color, 12); isClickable = true
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
        setOnClickListener { onClick() }
    }
}
