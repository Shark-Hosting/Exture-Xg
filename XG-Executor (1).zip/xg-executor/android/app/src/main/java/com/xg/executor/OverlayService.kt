package com.xg.executor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.SpannableString
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private const val C_BG = 0xFF0B1226.toInt()
private const val C_SURFACE = 0xFF111B38.toInt()
private const val C_SURFACE2 = 0xFF18264D.toInt()
private const val C_CYAN = 0xFF22D3EE.toInt()
private const val C_BLUE = 0xFF3B82F6.toInt()
private const val C_TEXT = 0xFFE2E8F0.toInt()
private const val C_MUTED = 0xFF64748B.toInt()
private const val C_RED = 0xFFEF4444.toInt()
private const val C_GREEN = 0xFF22C55E.toInt()
private const val C_AMBER = 0xFFFBBF24.toInt()

private const val DEFAULT_PY = "print(\"Hello from XG Executor\")\n"
private const val DEFAULT_LUA = "print(\"Hello from XG Executor\")\n"

/**
 * Foreground service that owns the floating XG icon, the draggable panel, and the connection
 * (polling) to the Termux engine. All UI is built natively with views in a WindowManager overlay.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_SHOW = "com.xg.executor.SHOW"
        const val ACTION_QUIT = "com.xg.executor.QUIT"
        const val EXTRA_PANEL = "panel"
        private const val CH_SERVICE = "xg_service"
        private const val CH_EVENTS = "xg_events"
        private const val NOTIF_ID = 1
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var nm: NotificationManager
    private lateinit var prefs: Prefs
    private lateinit var client: EngineClient
    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var pollThread: Thread? = null
    @Volatile private var alive = true

    private var sw = 0
    private var sh = 0
    private var density = 1f

    // views
    private lateinit var iconView: TextView
    private lateinit var iconLp: WindowManager.LayoutParams
    private lateinit var panel: LinearLayout
    private lateinit var panelLp: WindowManager.LayoutParams
    private var iconShown = false
    private var panelShown = false
    private var overlayHidden = false

    private lateinit var statusDot: View
    private lateinit var statusText: TextView
    private lateinit var tabs: List<TextView>
    private lateinit var pages: List<View>
    private lateinit var editor: EditText
    private lateinit var lineNumbers: TextView
    private lateinit var nameField: EditText
    private lateinit var langPy: TextView
    private lateinit var langLua: TextView
    private lateinit var consoleText: TextView
    private lateinit var consoleScroll: ScrollView
    private lateinit var jobLabel: TextView
    private lateinit var jobsList: LinearLayout
    private lateinit var pickerPage: LinearLayout
    private lateinit var pickerList: LinearLayout
    private lateinit var bgBtn: TextView

    // state
    private var lang = "python"
    private val buffers = mutableMapOf("python" to DEFAULT_PY, "lua" to DEFAULT_LUA)
    @Volatile private var curJob: String? = null
    @Volatile private var curSeq = 0L
    private var evSeq = -1L
    private var online = false
    private var everOnline = false
    private val knownJobs = LinkedHashMap<String, JSONObject>()
    private val jobRows = HashMap<String, JobRow>()
    private var lastNotifText = ""
    private var notifCounter = 100
    private val highlightRunnable = Runnable { Highlighter.apply(editor.text, lang == "lua") }

    private class JobRow(val root: LinearLayout, val info: TextView, val stop: TextView)

    private fun dp(v: Int) = (v * density).toInt()

    // ------------------------------------------------------------------ lifecycle

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        prefs = Prefs(this)
        client = EngineClient(prefs)
        density = resources.displayMetrics.density
        val b = wm.currentWindowMetrics.bounds
        sw = b.width(); sh = b.height()

        nm.createNotificationChannel(NotificationChannel(CH_SERVICE, "XG service", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_EVENTS, "Script notifications", NotificationManager.IMPORTANCE_DEFAULT))
        val n = buildNotif("Connecting to engine…")
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NOTIF_ID, n)

        buildIcon()
        buildPanel()
        pollThread = Thread({ pollLoop() }, "xg-poll").also { it.isDaemon = true; it.start() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_QUIT -> { quitAll(); return START_NOT_STICKY }
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "XG Executor needs 'Display over other apps' permission", Toast.LENGTH_LONG).show()
            shutdown(); return START_NOT_STICKY
        }
        overlayHidden = false
        if (intent?.getBooleanExtra(EXTRA_PANEL, false) == true) openPanel() else if (!panelShown) showIcon()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        alive = false
        pollThread?.interrupt()
        removeViews()
        io.shutdownNow()
        super.onDestroy()
    }

    private fun shutdown() {
        alive = false
        removeViews()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ------------------------------------------------------------------ notifications

    private fun buildNotif(text: String): Notification {
        val open = PendingIntent.getService(this, 1,
            Intent(this, OverlayService::class.java).setAction(ACTION_SHOW).putExtra(EXTRA_PANEL, true),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val quit = PendingIntent.getService(this, 2,
            Intent(this, OverlayService::class.java).setAction(ACTION_QUIT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_stat_xg)
            .setContentTitle("XG Executor")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(0, "Open", open).build())
            .addAction(Notification.Action.Builder(0, "Stop all & quit", quit).build())
            .build()
    }

    private fun updateServiceNotif() {
        val running = knownJobs.values.count { it.optString("status") == "running" }
        val text = when {
            !online -> "Engine offline: open Termux and run: xg start"
            running == 0 -> "Engine online, no jobs running"
            else -> "$running job(s) running"
        }
        if (text != lastNotifText) { lastNotifText = text; nm.notify(NOTIF_ID, buildNotif(text)) }
    }

    private fun postEvent(title: String, text: String) {
        val n = Notification.Builder(this, CH_EVENTS)
            .setSmallIcon(R.drawable.ic_stat_xg).setContentTitle(title).setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text)).setAutoCancel(true).build()
        nm.notify(notifCounter++, n)
    }

    // ------------------------------------------------------------------ view helpers

    private fun rr(color: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) setStroke(dp(strokeDp), strokeColor)
    }

    private fun button(label: String, bg: Int, fg: Int = C_BG, onClick: () -> Unit) = TextView(this).apply {
        text = label; setTextColor(fg); setTypeface(typeface, Typeface.BOLD); textSize = 12f
        gravity = Gravity.CENTER; setPadding(dp(10), dp(8), dp(10), dp(8))
        background = rr(bg, 10); isClickable = true
        setOnClickListener { onClick() }
    }

    private fun attachDrag(handle: View, lp: WindowManager.LayoutParams, view: View, onTap: (() -> Unit)?) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (!moved && (abs(dx) > dp(6) || abs(dy) > dp(6))) moved = true
                    if (moved) {
                        lp.x = (ox + dx).coerceIn(0, max(0, sw - max(view.width, 1)))
                        lp.y = (oy + dy).coerceIn(0, max(0, sh - max(view.height, 1)))
                        if (view.isAttachedToWindow) wm.updateViewLayout(view, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) onTap?.invoke(); true }
                else -> false
            }
        }
    }

    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    // ------------------------------------------------------------------ floating icon

    private fun buildIcon() {
        iconView = TextView(this).apply {
            text = "XG"; setTextColor(C_CYAN); setTypeface(typeface, Typeface.BOLD); textSize = 16f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(C_BG); setStroke(dp(2), C_CYAN)
            }
            elevation = dp(8).toFloat()
        }
        val size = dp(52)
        iconLp = WindowManager.LayoutParams(size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = sw - size - dp(8); y = sh / 3
        }
        attachDrag(iconView, iconLp, iconView) { openPanel() }
    }

    private fun showIcon() {
        if (iconShown) return
        wm.addView(iconView, iconLp); iconShown = true
        iconView.scaleX = 0.4f; iconView.scaleY = 0.4f
        iconView.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
    }

    private fun hideIcon() {
        if (!iconShown) return
        try { wm.removeView(iconView) } catch (_: Exception) {}
        iconShown = false
    }

    // ------------------------------------------------------------------ panel open / minimize / close

    private fun openPanel() {
        hideIcon()
        if (!panelShown) {
            wm.addView(panel, panelLp); panelShown = true
            panel.alpha = 0f; panel.animate().alpha(1f).setDuration(160).start()
        }
    }

    private fun minimize() {
        releaseFocus()
        if (panelShown) { try { wm.removeView(panel) } catch (_: Exception) {}; panelShown = false }
        // keep the icon where the panel header was
        iconLp.x = panelLp.x.coerceIn(0, max(0, sw - dp(52))); iconLp.y = panelLp.y.coerceIn(0, max(0, sh - dp(52)))
        showIcon()
    }

    /** Close: remove all overlays. Non-background jobs are stopped; background jobs keep running. */
    private fun closeAll() {
        releaseFocus()
        removeViews()
        overlayHidden = true
        val toStop = knownJobs.values.filter { it.optString("status") == "running" && !it.optBoolean("background") }
            .map { it.getString("id") }
        Thread {
            for (id in toStop) try { client.call("stop", "job" to id) } catch (_: Exception) {}
            ui.post { if (!hasRunningJobs()) shutdown() }
        }.start()
    }

    private fun quitAll() {
        Thread {
            try { client.call("stop_all") } catch (_: Exception) {}
            ui.post { shutdown() }
        }.start()
    }

    private fun hasRunningJobs() = knownJobs.values.any { it.optString("status") == "running" }

    private fun removeViews() {
        hideIcon()
        if (panelShown) { try { wm.removeView(panel) } catch (_: Exception) {}; panelShown = false }
    }

    // ------------------------------------------------------------------ keyboard focus handling

    private fun setFocusableWindow(focusable: Boolean) {
        if (!panelShown) return
        val f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        panelLp.flags = if (focusable) panelLp.flags and f.inv() else panelLp.flags or f
        wm.updateViewLayout(panel, panelLp)
    }

    private fun releaseFocus() {
        if (!::editor.isInitialized) return
        editor.clearFocus(); nameField.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(panel.windowToken, 0)
        setFocusableWindow(false)
    }

    private fun focusEditor(field: EditText) {
        setFocusableWindow(true)
        field.requestFocus()
        field.post { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(field, 0) }
    }

    // ------------------------------------------------------------------ panel UI

    private fun buildPanel() {
        val w = min(sw - dp(16), dp(430))
        val h = (sh * 0.66f).toInt()
        panelLp = WindowManager.LayoutParams(w, h, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (sw - w) / 2; y = dp(48)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rr(C_BG, 18, C_CYAN and 0x55FFFFFF, 1)
            elevation = dp(16).toFloat()
            setPadding(dp(10), dp(8), dp(10), dp(10))
        }

        // header (drag handle)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(8))
        }
        val logo = TextView(this).apply {
            text = "XG EXECUTOR"; setTextColor(C_CYAN); textSize = 15f
            setTypeface(typeface, Typeface.BOLD); letterSpacing = 0.12f
        }
        statusDot = View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(C_RED) } }
        statusText = TextView(this).apply { text = "OFFLINE"; setTextColor(C_MUTED); textSize = 10f }
        val spacer = View(this)
        header.addView(logo)
        header.addView(statusDot, LinearLayout.LayoutParams(dp(8), dp(8)).apply { leftMargin = dp(10); rightMargin = dp(4) })
        header.addView(statusText)
        header.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        header.addView(button("–", C_SURFACE2, C_TEXT) { minimize() }, LinearLayout.LayoutParams(dp(36), dp(32)))
        header.addView(button("✕", C_SURFACE2, C_RED) { closeAll() }, LinearLayout.LayoutParams(dp(36), dp(32)).apply { leftMargin = dp(6) })
        panel.addView(header, LinearLayout.LayoutParams(-1, -2))
        attachDrag(header, panelLp, panel, null)

        // tabs
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val names = listOf("EDITOR", "CONSOLE", "JOBS")
        tabs = names.mapIndexed { i, n ->
            TextView(this).apply {
                text = n; gravity = Gravity.CENTER; textSize = 11f; setTypeface(typeface, Typeface.BOLD)
                setPadding(0, dp(7), 0, dp(7)); isClickable = true
                setOnClickListener { showTab(i) }
            }
        }
        tabs.forEach { tabRow.addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        panel.addView(tabRow, LinearLayout.LayoutParams(-1, -2))

        // pages
        val content = FrameLayout(this)
        val editorPage = buildEditorPage()
        val consolePage = buildConsolePage()
        val jobsPage = buildJobsPage()
        buildPickerPage()
        pages = listOf(editorPage, consolePage, jobsPage)
        content.addView(editorPage, FrameLayout.LayoutParams(-1, -1))
        content.addView(consolePage, FrameLayout.LayoutParams(-1, -1))
        content.addView(jobsPage, FrameLayout.LayoutParams(-1, -1))
        content.addView(pickerPage, FrameLayout.LayoutParams(-1, -1))
        panel.addView(content, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(6) })

        // controls
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val exec = button("▶  EXECUTE", C_CYAN) { releaseFocus(); execute() }
        val stop = button("■  STOP", C_RED, Color.WHITE) { releaseFocus(); stopCurrent() }
        bgBtn = button("", C_SURFACE2, C_TEXT) { prefs.background = !prefs.background; refreshBgBtn() }
        controls.addView(exec, LinearLayout.LayoutParams(0, dp(40), 1.3f))
        controls.addView(stop, LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(6) })
        controls.addView(bgBtn, LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(6) })
        panel.addView(controls, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        refreshBgBtn()
        showTab(0)
    }

    private fun refreshBgBtn() {
        val on = prefs.background
        bgBtn.text = if (on) "BG: ON" else "BG: OFF"
        bgBtn.background = rr(if (on) C_BLUE else C_SURFACE2, 10)
        bgBtn.setTextColor(if (on) Color.WHITE else C_MUTED)
    }

    private fun showTab(i: Int) {
        pages.forEachIndexed { idx, p -> p.visibility = if (idx == i) View.VISIBLE else View.GONE }
        pickerPage.visibility = View.GONE
        tabs.forEachIndexed { idx, t ->
            t.setTextColor(if (idx == i) C_CYAN else C_MUTED)
            t.background = if (idx == i) rr(C_SURFACE, 8) else null
        }
        if (i != 0) releaseFocus()
    }

    private fun buildEditorPage(): LinearLayout {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        langPy = button("PYTHON", C_BLUE, Color.WHITE) { setLang("python") }
        langLua = button("LUA", C_SURFACE2, C_MUTED) { setLang("lua") }
        nameField = EditText(this).apply {
            setText("untitled.py"); setTextColor(C_TEXT); textSize = 12f; setSingleLine(true)
            background = rr(C_SURFACE, 8); setPadding(dp(8), dp(6), dp(8), dp(6))
            setTypeface(Typeface.MONOSPACE)
            setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_DOWN) focusEditor(this); false }
        }
        top.addView(langPy, LinearLayout.LayoutParams(-2, dp(34)))
        top.addView(langLua, LinearLayout.LayoutParams(-2, dp(34)).apply { leftMargin = dp(6) })
        top.addView(nameField, LinearLayout.LayoutParams(0, dp(34), 1f).apply { leftMargin = dp(8) })
        page.addView(top, LinearLayout.LayoutParams(-1, -2))

        lineNumbers = TextView(this).apply {
            setTextColor(C_MUTED); textSize = 12f; typeface = Typeface.MONOSPACE; gravity = Gravity.END
            setPadding(dp(6), dp(8), dp(6), dp(8)); text = "1"
        }
        editor = EditText(this).apply {
            setTextColor(C_TEXT); textSize = 12f; typeface = Typeface.MONOSPACE
            background = null; gravity = Gravity.TOP or Gravity.START
            setPadding(dp(6), dp(8), dp(8), dp(8)); setHorizontallyScrolling(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            setText(DEFAULT_PY)
            setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_DOWN) focusEditor(this); false }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable) {
                    val n = s.count { it == '\n' } + 1
                    if (lineNumbers.tag != n) {
                        lineNumbers.tag = n
                        lineNumbers.text = (1..n).joinToString("\n")
                    }
                    ui.removeCallbacks(highlightRunnable); ui.postDelayed(highlightRunnable, 250)
                }
            })
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(lineNumbers, LinearLayout.LayoutParams(-2, -2))
        row.addView(editor, LinearLayout.LayoutParams(0, -2, 1f))
        val scroll = ScrollView(this).apply {
            isFillViewport = true; background = rr(C_SURFACE, 10)
            addView(row, ViewGroup.LayoutParams(-1, -2))
        }
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(6) })
        Highlighter.apply(editor.text, false)

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val m = { LinearLayout.LayoutParams(0, dp(34), 1f).apply { leftMargin = dp(4); rightMargin = dp(4) } }
        bar.addView(button("PASTE", C_SURFACE2, C_TEXT) { pasteClipboard() }, m())
        bar.addView(button("CLEAR", C_SURFACE2, C_TEXT) { editor.setText("") ; focusEditor(editor) }, m())
        bar.addView(button("SAVE", C_SURFACE2, C_CYAN) { releaseFocus(); saveScript() }, m())
        bar.addView(button("LOAD", C_SURFACE2, C_CYAN) { releaseFocus(); showPicker() }, m())
        page.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        return page
    }

    private fun buildConsolePage(): LinearLayout {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        jobLabel = TextView(this).apply { text = "No job selected"; setTextColor(C_MUTED); textSize = 11f }
        top.addView(jobLabel, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(button("CLEAR", C_SURFACE2, C_TEXT) { consoleText.text = "" }, LinearLayout.LayoutParams(-2, dp(28)))
        page.addView(top, LinearLayout.LayoutParams(-1, -2))
        consoleText = TextView(this).apply {
            textSize = 11.5f; typeface = Typeface.MONOSPACE; setTextColor(C_TEXT)
            setPadding(dp(8), dp(8), dp(8), dp(8)); setTextIsSelectable(true)
        }
        consoleScroll = ScrollView(this).apply {
            background = rr(0xFF070D1C.toInt(), 10); addView(consoleText, ViewGroup.LayoutParams(-1, -2))
        }
        page.addView(consoleScroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(6) })
        consoleText.append(colored("[xg] runtime: Termux engine at 127.0.0.1:${prefs.port} (token-authenticated)\n", C_CYAN))
        return page
    }

    private fun buildJobsPage(): LinearLayout {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(button("STOP ALL", C_RED, Color.WHITE) { io.execute { try { client.call("stop_all") } catch (_: Exception) {} } },
            LinearLayout.LayoutParams(0, dp(32), 1f).apply { rightMargin = dp(4) })
        top.addView(button("CLEAR FINISHED", C_SURFACE2, C_TEXT) {
            io.execute { try { client.call("clear_finished") } catch (_: Exception) {} }
        }, LinearLayout.LayoutParams(0, dp(32), 1f).apply { leftMargin = dp(4) })
        page.addView(top, LinearLayout.LayoutParams(-1, -2))
        jobsList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sc = ScrollView(this).apply { addView(jobsList, ViewGroup.LayoutParams(-1, -2)) }
        page.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(6) })
        return page
    }

    private fun buildPickerPage() {
        pickerPage = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rr(C_BG, 10); visibility = View.GONE
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply { text = "SAVED SCRIPTS"; setTextColor(C_CYAN); textSize = 12f; setTypeface(typeface, Typeface.BOLD) },
            LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(button("BACK", C_SURFACE2, C_TEXT) { pickerPage.visibility = View.GONE }, LinearLayout.LayoutParams(-2, dp(30)))
        pickerPage.addView(top, LinearLayout.LayoutParams(-1, -2))
        pickerList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pickerPage.addView(ScrollView(this).apply { addView(pickerList, ViewGroup.LayoutParams(-1, -2)) },
            LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(6) })
    }

    // ------------------------------------------------------------------ editor actions

    private fun setLang(newLang: String) {
        if (newLang == lang) return
        buffers[lang] = editor.text.toString()
        lang = newLang
        editor.setText(buffers[lang])
        langPy.background = rr(if (lang == "python") C_BLUE else C_SURFACE2, 10)
        langPy.setTextColor(if (lang == "python") Color.WHITE else C_MUTED)
        langLua.background = rr(if (lang == "lua") C_BLUE else C_SURFACE2, 10)
        langLua.setTextColor(if (lang == "lua") Color.WHITE else C_MUTED)
        val base = nameField.text.toString().substringBeforeLast('.', nameField.text.toString())
        nameField.setText(base + extFor(lang))
        Highlighter.apply(editor.text, lang == "lua")
    }

    private fun extFor(l: String) = if (l == "lua") ".lua" else ".py"

    private fun scriptName(): String {
        var n = nameField.text.toString().trim().ifEmpty { "untitled" }
        if (!n.endsWith(".py") && !n.endsWith(".lua")) n += extFor(lang)
        return n
    }

    private fun pasteClipboard() {
        setFocusableWindow(true)
        editor.requestFocus()
        // Android only allows clipboard reads for the focused window, so wait for focus first.
        ui.postDelayed({
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val txt = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)
            if (txt.isNullOrEmpty()) {
                Toast.makeText(this, "Clipboard unavailable: long-press the editor and choose Paste", Toast.LENGTH_LONG).show()
            } else {
                val s = min(editor.selectionStart.coerceAtLeast(0), editor.selectionEnd.coerceAtLeast(0))
                val e = max(editor.selectionStart.coerceAtLeast(0), editor.selectionEnd.coerceAtLeast(0))
                editor.text.replace(s, e, txt)
            }
        }, 200)
    }

    private fun saveScript() {
        val name = scriptName(); val code = editor.text.toString()
        nameField.setText(name)
        io.execute {
            try {
                client.call("save", "name" to name, "code" to code)
                ui.post { sysLine("[xg] saved $name") }
            } catch (e: Exception) { ui.post { sysLine("[xg] save failed: ${e.message}", C_RED) } }
        }
    }

    private fun showPicker() {
        io.execute {
            try {
                val arr = client.call("list_scripts").getJSONArray("scripts")
                ui.post {
                    pickerList.removeAllViews()
                    if (arr.length() == 0) pickerList.addView(TextView(this).apply {
                        text = "No saved scripts yet. Use SAVE."; setTextColor(C_MUTED); setPadding(dp(8), dp(12), dp(8), dp(12))
                    })
                    for (i in 0 until arr.length()) pickerList.addView(pickerRow(arr.getString(i)))
                    pickerPage.visibility = View.VISIBLE
                }
            } catch (e: Exception) { ui.post { sysLine("[xg] cannot list scripts: ${e.message}", C_RED) } }
        }
    }

    private fun pickerRow(name: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rr(C_SURFACE, 8); setPadding(dp(10), dp(4), dp(4), dp(4))
        }
        row.addView(TextView(this).apply {
            text = name; setTextColor(C_TEXT); textSize = 13f; typeface = Typeface.MONOSPACE; isClickable = true
            setPadding(0, dp(8), 0, dp(8)); setOnClickListener { loadScript(name) }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(button("✕", C_SURFACE2, C_RED) {
            io.execute { try { client.call("delete", "name" to name) } catch (_: Exception) {}; ui.post { showPicker() } }
        }, LinearLayout.LayoutParams(dp(34), dp(30)))
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(4)); addView(row)
        }
    }

    private fun loadScript(name: String) {
        io.execute {
            try {
                val r = client.call("load", "name" to name)
                ui.post {
                    setLang(if (name.endsWith(".lua")) "lua" else "python")
                    editor.setText(r.getString("code")); nameField.setText(name)
                    pickerPage.visibility = View.GONE
                }
            } catch (e: Exception) { ui.post { sysLine("[xg] load failed: ${e.message}", C_RED) } }
        }
    }

    // ------------------------------------------------------------------ execute / stop

    private fun execute() {
        val code = editor.text.toString()
        if (code.isBlank()) { sysLine("[xg] nothing to execute", C_AMBER); showTab(1); return }
        val l = lang; val name = scriptName(); val bg = prefs.background
        prefs.lastCode = code
        io.execute {
            try {
                val r = client.call("exec", "lang" to l, "code" to code, "name" to name, "background" to bg)
                val id = r.getString("job")
                ui.post { selectJob(id); showTab(1) }
            } catch (e: Exception) {
                ui.post { sysLine("[xg] execute failed: ${e.message}", C_RED); showTab(1) }
            }
        }
    }

    private fun stopCurrent() {
        val cur = curJob
        val ids = if (cur != null && knownJobs[cur]?.optString("status") == "running") listOf(cur)
        else knownJobs.values.filter { it.optString("status") == "running" }.map { it.getString("id") }
        if (ids.isEmpty()) { sysLine("[xg] no running job to stop", C_AMBER); showTab(1); return }
        io.execute {
            for (id in ids) try { client.call("stop", "job" to id) }
            catch (e: Exception) { ui.post { sysLine("[xg] stop failed: ${e.message}", C_RED) } }
        }
    }

    private fun selectJob(id: String) {
        curJob = id; curSeq = 0
        consoleText.text = ""
        jobLabel.text = "Job #$id"
        jobLabel.setTextColor(C_CYAN)
    }

    // ------------------------------------------------------------------ console

    private fun colored(text: String, color: Int) = SpannableString(text).apply {
        setSpan(ForegroundColorSpan(color), 0, length, 0)
    }

    private fun sysLine(text: String, color: Int = C_CYAN) = appendConsole(text, color)

    private fun appendConsole(text: String, color: Int) {
        consoleText.append(colored(text + "\n", color))
        val ed = consoleText.text
        if (ed is Editable && ed.length > 80_000) ed.delete(0, 20_000)
        consoleScroll.post { consoleScroll.scrollTo(0, consoleText.bottom) }
    }

    // ------------------------------------------------------------------ polling

    private fun pollLoop() {
        var fails = 0
        while (alive) {
            try {
                if (evSeq < 0) evSeq = client.call("events", "since" to 1_000_000_000_000L).getLong("seq")
                val ev = client.call("events", "since" to evSeq)
                val newSeq = ev.getLong("seq")
                val events = ev.getJSONArray("events")
                val jobs = client.call("jobs").getJSONArray("jobs")
                val cj = curJob
                val out = if (cj != null) client.call("output", "job" to cj, "since" to curSeq) else null
                fails = 0
                ui.post { evSeq = newSeq; applyPoll(events, jobs, cj, out) }
            } catch (e: InterruptedException) {
                return
            } catch (e: Exception) {
                fails++
                if (fails == 2) { val msg = e.message ?: "connection failed"; ui.post { setOnline(false, msg) } }
            }
            try { Thread.sleep(if (panelShown) 600 else 1500) } catch (_: InterruptedException) { return }
        }
    }

    private fun setOnline(on: Boolean, reason: String = "") {
        if (on == online && everOnline) return
        val was = online
        online = on
        statusDot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (on) C_GREEN else C_RED) }
        statusText.text = if (on) "ENGINE ONLINE" else "OFFLINE"
        statusText.setTextColor(if (on) C_GREEN else C_MUTED)
        if (on) { everOnline = true; if (!was) sysLine("[xg] engine online") }
        else {
            sysLine("[xg] engine offline: $reason. Termux may have been closed or killed by Android; run 'xg start'.", C_RED)
            if (was || everOnline) postEvent("XG engine offline", "Termux engine is not reachable ($reason). Open Termux and run: xg start")
        }
        updateServiceNotif()
    }

    private fun applyPoll(events: JSONArray, jobs: JSONArray, polledJob: String?, out: JSONObject?) {
        if (!online) setOnline(true)

        // jobs
        val seen = HashSet<String>()
        knownJobs.clear()
        for (i in 0 until jobs.length()) {
            val j = jobs.getJSONObject(i); knownJobs[j.getString("id")] = j; seen.add(j.getString("id"))
        }
        refreshJobsUi(seen)

        // events
        for (i in 0 until events.length()) {
            val e = events.getJSONObject(i)
            when (e.optString("type")) {
                "notify" -> postEvent(e.optString("title", "XG Executor"), e.optString("text"))
                "android" -> {
                    val err = XgAccessibilityService.perform(e.optString("action"), e.optJSONObject("args") ?: JSONObject())
                    if (err != null) sysLine("[xg] android.${e.optString("action")} (job ${e.optString("job")}): $err", C_AMBER)
                }
                "job" -> {
                    val st = e.optString("status"); val nm = e.optString("name"); val id = e.optString("job")
                    when (st) {
                        "failed" -> postEvent("Job #$id failed", "$nm exited with code ${e.optInt("exit_code")}")
                        "killed" -> postEvent("Job #$id was killed", "$nm was terminated by the system. See README > Background execution.")
                        "finished" -> if (knownJobs[id]?.optBoolean("background") == true) postEvent("Job #$id finished", nm)
                    }
                }
                "job_lost" -> postEvent("XG job lost", e.optString("message"))
            }
        }

        // console output of the selected job
        if (out != null && polledJob == curJob) {
            val lines = out.getJSONArray("lines")
            for (i in 0 until lines.length()) {
                val l = lines.getJSONArray(i)
                val color = when (l.getString(1)) { "err" -> C_RED; "sys" -> C_CYAN; "log" -> C_AMBER; else -> C_TEXT }
                appendConsole(l.getString(2), color)
            }
            curSeq = out.getLong("seq")
            val info = out.getJSONObject("info")
            jobLabel.text = "Job #${info.getString("id")} · ${info.getString("name")} · ${info.getString("status").uppercase()}"
            jobLabel.setTextColor(statusColor(info.getString("status")))
        }
        updateServiceNotif()
        if (overlayHidden && !hasRunningJobs()) shutdown()
    }

    private fun statusColor(s: String) = when (s) {
        "running", "starting" -> C_GREEN; "finished" -> C_CYAN; "stopped" -> C_AMBER; else -> C_RED
    }

    private fun refreshJobsUi(seen: Set<String>) {
        for (id in jobRows.keys.toList()) if (id !in seen) { jobsList.removeView(jobRows[id]!!.root); jobRows.remove(id) }
        for (j in knownJobs.values.sortedByDescending { it.getString("id").toInt() }) {
            val id = j.getString("id")
            val row = jobRows.getOrPut(id) { newJobRow(id).also { jobsList.addView(it.root, 0) } }
            val st = j.getString("status")
            val sstat = j.optString("script_status")
            row.info.text = "#$id  ${j.optString("name")}  (${j.optString("lang")}${if (j.optBoolean("background")) ", bg" else ""})\n" +
                "${st.uppercase()}  ${j.optDouble("elapsed").toInt()}s" + (if (sstat.isNotEmpty()) "  ·  $sstat" else "")
            row.info.setTextColor(statusColor(st))
            row.stop.visibility = if (st == "running") View.VISIBLE else View.GONE
        }
    }

    private fun newJobRow(id: String): JobRow {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rr(C_SURFACE, 10); setPadding(dp(10), dp(6), dp(6), dp(6))
        }
        val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) }
        root.layoutParams = lp
        val info = TextView(this).apply { textSize = 11f; typeface = Typeface.MONOSPACE; setTextColor(C_TEXT) }
        root.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(button("VIEW", C_SURFACE2, C_CYAN) { selectJob(id); showTab(1) }, LinearLayout.LayoutParams(-2, dp(30)))
        val stop = button("STOP", C_RED, Color.WHITE) {
            io.execute { try { client.call("stop", "job" to id) } catch (_: Exception) {} }
        }
        root.addView(stop, LinearLayout.LayoutParams(-2, dp(30)).apply { leftMargin = dp(4) })
        return JobRow(root, info, stop)
    }
}
