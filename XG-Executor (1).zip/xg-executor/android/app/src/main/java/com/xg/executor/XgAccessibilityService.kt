package com.xg.executor

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import org.json.JSONObject

/**
 * User-approved automation backend for xg.android.* calls.
 * It only dispatches standard accessibility gestures / global actions in the foreground app.
 * It does not read screen content (canRetrieveWindowContent=false) and does not touch other processes.
 */
class XgAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: XgAccessibilityService? = null

        /** Returns null on success or an error message. */
        fun perform(action: String, args: JSONObject): String? {
            val svc = instance ?: return "Accessibility service is not enabled (Settings > Accessibility > XG Executor)"
            return when (action) {
                "back" -> check(svc.performGlobalAction(GLOBAL_ACTION_BACK), action)
                "home" -> check(svc.performGlobalAction(GLOBAL_ACTION_HOME), action)
                "recents" -> check(svc.performGlobalAction(GLOBAL_ACTION_RECENTS), action)
                "notifications" -> check(svc.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS), action)
                "tap" -> svc.gesture(args.optDouble("x"), args.optDouble("y"), args.optDouble("x"), args.optDouble("y"), 50)
                "swipe" -> svc.gesture(args.optDouble("x"), args.optDouble("y"), args.optDouble("x2"), args.optDouble("y2"),
                    args.optLong("ms", 300).coerceIn(50, 5000))
                else -> "unknown action $action"
            }
        }

        private fun check(ok: Boolean, name: String) = if (ok) null else "$name failed"
    }

    private fun gesture(x1: Double, y1: Double, x2: Double, y2: Double, ms: Long): String? {
        if (x1.isNaN() || y1.isNaN() || x2.isNaN() || y2.isNaN()) return "missing coordinates"
        val path = Path().apply {
            moveTo(x1.toFloat(), y1.toFloat())
            if (x1 != x2 || y1 != y2) lineTo(x2.toFloat(), y2.toFloat())
        }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, ms)).build()
        return if (dispatchGesture(g, null, null)) null else "gesture rejected by Android"
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
