# XG Executor

Native Android floating script executor (Python + Lua) for Termux.
Package `com.xg.executor` · Android 11+ (target: Galaxy A70) · UI language: English.

```
 ┌──────────── Android app (Kotlin) ───────────┐         ┌──────────── Termux ───────────┐
 │ Floating icon + draggable panel (overlay)    │  JSON   │ xg_engine.py (Python 3)        │
 │ Foreground service + notification            │ lines   │  • job manager (process groups)│
 │ AccessibilityService (taps/swipes, opt-in)   │◄───────►│  • python3 / lua5.4 runtimes   │
 │ EngineClient ── 127.0.0.1:47821 + token ─────┼─────────┼─►• script store ~/.xg/scripts  │
 └──────────────────────────────────────────────┘         └────────────────────────────────┘
```

## Honest status

| Part | Verified here |
|---|---|
| Python engine: exec, stop, multiple jobs, background, auth, status, kill detection, script store | **Yes**, `engine/test_engine.py` (25 checks, run in a Linux sandbox) |
| Lua runtime path (`xg.lua`, Lua job launch) | **Not run**: no Lua binary in the build sandbox. Written and reviewed only; run `xg test` and the Lua example on your phone |
| Android APK (Kotlin) | **Not compiled or run**: the sandbox has no Android SDK/Gradle/network. Expect to fix small compile errors on first build |
| Overlay, accessibility gestures, notifications, Termux RUN_COMMAND | **Not tested on a device** |

## 1. Install the engine (Termux)

Install Termux from **F-Droid** (not the Play Store build). Copy the `engine/` folder to the phone
(e.g. `~/xg-executor/engine`), then:

```bash
cd ~/xg-executor/engine
bash install.sh        # installs python + lua54, creates ~/.xg, the `xg` command, runs self-test
xg start               # start the engine (background, wake-lock)
xg token               # prints the shared secret
```

Other commands: `xg stop`, `xg restart`, `xg status`, `xg logs`, `xg test`.

## 2. Build the APK

You need JDK 17 and the Android SDK (Android Studio is easiest).

* Android Studio: open the `android/` folder → **Build ▸ Build APK(s)**.
* CLI (Gradle 8.7+ installed, `ANDROID_HOME` set): `cd android && gradle assembleDebug`
  → `android/app/build/outputs/apk/debug/app-debug.apk`

Building on the phone itself in Termux is not supported here (the Android SDK's aapt2 doesn't run natively).

## 3. Install the APK

`adb install -r app-debug.apk`, or copy it to the phone and open it (allow "install unknown apps").

## 4. First run

1. Open **XG Executor** → grant **Display over other apps** and **Notifications**.
2. Paste the token (`xg token` in Termux) → **Save & test connection** (should show engine/Python/Lua info).
3. Tap **LAUNCH FLOATING PANEL**. The XG icon appears; open any other app, tap the icon for the panel.
4. Optional: Accessibility ▸ XG Executor ▸ On, only if you want `xg.android.*`.
5. Optional: battery settings → exempt both **XG Executor** and **Termux**.

Optional one-tap engine start from the app: in Termux add `allow-external-apps=true` to
`~/.termux/termux.properties`, run `termux-reload-settings`, and grant XG the
"Run commands in Termux environment" permission in Android app settings.

## Panel guide

* **Header**: drag to move · `–` minimize to icon · `✕` close.
  Close stops jobs that were started with BG: OFF; BG: ON jobs keep running (the foreground notification stays until they finish).
* **EDITOR**: Python/Lua toggle, script name, syntax highlighting, line numbers, PASTE, CLEAR, SAVE, LOAD.
* **CONSOLE**: live stdout (white), stderr (red), `[xg]` status (cyan), `xg.log` (amber).
* **JOBS**: all jobs, VIEW/STOP each, STOP ALL, CLEAR FINISHED.
* **EXECUTE / STOP / BG**: run the editor code · stop the selected job (or all if none selected) · background mode.
* The notification has **Open** and **Stop all & quit**. Quitting the panel never stops the Termux engine itself (`xg stop`).
* While you type, the panel takes keyboard focus; it releases it when you press EXECUTE/STOP, change tab or minimize, so other apps keep working.

## Script API

Python: `import xg`   Lua: `local xg = require("xg")`

| Call | Meaning |
|---|---|
| `print(...)` | stdout to console |
| `xg.log(text[, level])` | leveled log line |
| `xg.status(text)` | status shown in the Jobs list |
| `xg.notify(text[, title])` | Android notification via the XG app |
| `xg.sleep(s)` / `xg.every(s, fn[, count])` / `xg.after(s, fn)` | timers (blocking, in the script's own process) |
| `xg.android.tap(x, y)` · `swipe(x, y, x2, y2[, ms])` · `back()` · `home()` · `recents()` · `notifications()` | needs the Accessibility service; fire-and-forget; errors appear in the console |

How it works: API calls print a control line (`\x1eXG\x1e{json}`) that the engine intercepts; no sockets or extra libraries are needed in scripts. Examples are in `engine/examples/`.

## Background execution

* Jobs are separate process groups under the engine and keep running while the panel is minimized or another app is in front.
* STOP sends SIGTERM to the group (then SIGKILL after 2 s), so child processes die too.
* If Android kills a job (signal exit) the console shows the signal and you get a "Job killed" notification; if the engine/Termux dies, the app shows OFFLINE and notifies you, and on next `xg start` orphaned jobs are reported as lost.
* Android may still kill Termux: exempt Termux and XG from battery optimization, keep the Termux wake-lock notification, and on Android 12+ consider disabling the phantom-process killer via adb:
  `adb shell "settings put global settings_enable_monitor_phantom_procs false"` (Samsung One UI also has "Put unused apps to sleep" / "Sleeping apps": remove Termux and XG).

## Security model

* The engine binds **127.0.0.1 only** and every request must carry the 128-bit token from `~/.xg/token` (file mode 600, compared in constant time); wrong token = connection dropped. Requests are size-limited and validated; script names can't contain paths.
* Anyone who can read the token (or another app that gets it from you) can run code as Termux. Don't share it; delete `~/.xg/token` and `xg restart` to rotate (then re-paste in the app).
* **Scripts run with Termux's permissions** (Termux's files and storage grants), not with XG's.
* XG injects nothing into other apps, reads no screen content, and does not bypass app security or anti-cheat. Accessibility is optional, user-enabled in Android settings, and limited to gestures/global actions.
* Another app on the same phone can open the loopback port but cannot do anything without the token.

## Troubleshooting

| Symptom | Fix |
|---|---|
| "Failed: ... Connection refused" | Engine not running: `xg start`; check port matches (`XG_PORT`, default 47821) |
| "unauthorized" | Token mismatch: re-run `xg token`, paste again |
| Lua says "Lua 5.4 not found" | `pkg install lua54`; check `which lua5.4 lua` |
| Icon doesn't appear | Overlay permission missing; on Samsung also check Settings ▸ Apps ▸ XG ▸ Appear on top |
| Panel won't accept typing | Tap inside the editor; if a game steals focus, minimize then reopen |
| App goes OFFLINE after a while | Battery/phantom-process killer, see Background execution |
| `xg.android.*` does nothing | Enable Accessibility ▸ XG Executor; some secure screens block gestures |
| PASTE does nothing | Android restricts background clipboard reads: long-press in the editor ▸ Paste |
| Build error | Use JDK 17 and Gradle 8.7+/AGP 8.5; report the exact message |
| Termux "Start engine" button fails | Needs `allow-external-apps=true` + RUN_COMMAND permission, or just run `xg start` |

## Stop everything

`xg stop` (engine) · notification ▸ *Stop all & quit* (panel/service).

## Build the APK without a PC (GitHub Actions)

1. Create a GitHub repository and upload the **contents** of this project (including the hidden `.github` folder) so that `android/` and `.github/` are at the repo root.
2. Open the repo's **Actions** tab → *Build XG Executor APK* → wait for the green check (≈5 min).
3. Open the run → **Artifacts** → download `XG-Executor-APK` → unzip → `app-debug.apk`.
If the run fails, open the failed step and copy the error text.
