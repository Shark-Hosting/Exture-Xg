# Runs until you press STOP. Try it with Background ON and switch apps.
import xg
n = 0
while True:
    n += 1
    xg.status("loop #%d" % n)
    print("alive", n)
    xg.sleep(2)
