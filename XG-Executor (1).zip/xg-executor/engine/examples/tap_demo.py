# Requires: Settings > Accessibility > XG Executor > ON
import xg
xg.sleep(3)              # switch to the target app first
xg.android.swipe(540, 1500, 540, 600, 400)
xg.android.tap(540, 1000)
xg.android.home()
