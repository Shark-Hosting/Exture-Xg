local xg = require("xg")
print("Hello from XG Executor")
xg.log("logging works")
xg.status("counting")
for i = 1, 3 do
  print("tick", i)
  xg.sleep(0.5)
end
xg.notify("hello.lua finished", "XG Example")
