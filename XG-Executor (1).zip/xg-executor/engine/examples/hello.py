import xg
print("Hello from XG Executor")
xg.log("logging works")
xg.status("counting")
for i in range(1, 4):
    print("tick", i)
    xg.sleep(0.5)
xg.notify("hello.py finished", "XG Example")
