#!/usr/bin/env python3
"""XG Executor engine (Termux side).

Authenticated, loopback-only JSON-lines server. Runs Python and Lua jobs as
independent process groups, streams their output, tracks status.

Script -> engine control channel: a script prints a line that starts with the
sentinel "\x1eXG\x1e" followed by JSON. The XG API libraries (xg.py / xg.lua)
do this for you. Everything else on stdout/stderr is plain console output.
"""
import hmac, json, os, secrets, shutil, signal, socket, socketserver, subprocess
import sys, threading, time, traceback

HOME = os.path.expanduser("~")
XG_HOME = os.environ.get("XG_HOME", os.path.join(HOME, ".xg"))
SCRIPTS = os.path.join(XG_HOME, "scripts")
TOKEN_FILE = os.path.join(XG_HOME, "token")
STATE_FILE = os.path.join(XG_HOME, "jobs.json")
LIB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "lib")
HOST = "127.0.0.1"
PORT = int(os.environ.get("XG_PORT", "47821"))
SENTINEL = "\x1eXG\x1e"
MAX_LINES = 5000
MAX_REQ = 2 * 1024 * 1024
LANGS = {"python": (".py", None), "lua": (".lua", None)}


def ensure_home():
    os.makedirs(SCRIPTS, mode=0o700, exist_ok=True)
    os.chmod(XG_HOME, 0o700)
    if not os.path.exists(TOKEN_FILE):
        with open(os.open(TOKEN_FILE, os.O_WRONLY | os.O_CREAT, 0o600), "w") as f:
            f.write(secrets.token_hex(16))
    return open(TOKEN_FILE).read().strip()


def find_runtime(lang):
    if lang == "python":
        return [sys.executable or shutil.which("python3") or "python3", "-u"]
    for name in ("lua5.4", "lua", "lua54"):
        p = shutil.which(name)
        if p:
            return [p]
    return None


class Job:
    def __init__(self, jid, lang, name, code, background):
        self.id, self.lang, self.name, self.background = jid, lang, name, background
        self.code = code
        self.status = "starting"     # starting running finished failed stopped killed
        self.exit_code = None
        self.started = time.time()
        self.ended = None
        self.script_status = ""
        self.lines = []               # (seq, stream, text)
        self.seq = 0
        self.proc = None
        self.stop_requested = False
        self.lock = threading.Lock()

    def add(self, stream, text):
        with self.lock:
            self.seq += 1
            self.lines.append((self.seq, stream, text))
            if len(self.lines) > MAX_LINES:
                del self.lines[: len(self.lines) - MAX_LINES]

    def info(self):
        end = self.ended or time.time()
        return {"id": self.id, "lang": self.lang, "name": self.name, "status": self.status,
                "exit_code": self.exit_code, "pid": self.proc.pid if self.proc else None,
                "elapsed": round(end - self.started, 1), "script_status": self.script_status,
                "background": self.background}


class Engine:
    def __init__(self):
        self.jobs = {}
        self.next_id = 1
        self.events = []
        self.ev_seq = 0
        self.lock = threading.Lock()
        self.started = time.time()
        self._mark_lost_jobs()

    # ---- events for the APK (notifications, android actions, job changes)
    def event(self, kind, **data):
        with self.lock:
            self.ev_seq += 1
            self.events.append({"seq": self.ev_seq, "type": kind, "time": time.time(), **data})
            del self.events[:-500]

    def _mark_lost_jobs(self):
        try:
            old = json.load(open(STATE_FILE))
        except Exception:
            return
        for j in old:
            if j.get("status") in ("running", "starting"):
                self.event("job_lost", job=j["id"], name=j.get("name"),
                           message="Engine restarted; job %s (%s) was lost (Android or the user ended Termux)."
                           % (j["id"], j.get("name")))
                # best effort: kill orphaned process group
                pid = j.get("pid")
                if pid:
                    try:
                        os.killpg(os.getpgid(pid), signal.SIGKILL)
                    except Exception:
                        pass

    def _save_state(self):
        try:
            tmp = STATE_FILE + ".tmp"
            json.dump([j.info() for j in self.jobs.values()], open(tmp, "w"))
            os.replace(tmp, STATE_FILE)
        except Exception:
            pass

    # ---- jobs
    def start(self, lang, code, name, background):
        if lang not in LANGS:
            raise ValueError("unsupported language: %r" % lang)
        rt = find_runtime(lang)
        if not rt:
            raise RuntimeError("Lua 5.4 not found. Run: pkg install lua54")
        with self.lock:
            jid = str(self.next_id)
            self.next_id += 1
        ext = LANGS[lang][0]
        work = os.path.join(XG_HOME, "run")
        os.makedirs(work, exist_ok=True)
        path = os.path.join(work, "job%s%s" % (jid, ext))
        with open(path, "w") as f:
            f.write(code)
        job = Job(jid, lang, name or ("untitled" + ext), code, background)
        env = dict(os.environ, XG_JOB_ID=jid, XG_JOB_NAME=job.name, PYTHONUNBUFFERED="1",
                   PYTHONPATH=LIB_DIR + os.pathsep + os.environ.get("PYTHONPATH", ""),
                   LUA_PATH=os.path.join(LIB_DIR, "?.lua") + ";;")
        try:
            job.proc = subprocess.Popen(rt + [path], stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE, cwd=SCRIPTS, env=env,
                                        start_new_session=True, bufsize=0)
        except Exception as e:
            job.status, job.exit_code, job.ended = "failed", -1, time.time()
            job.add("err", "Could not start runtime: %s" % e)
            self.jobs[jid] = job
            raise
        job.status = "running"
        job.add("sys", "[xg] job %s started (%s, pid %d)%s" % (jid, lang, job.proc.pid, " in background" if background else ""))
        self.jobs[jid] = job
        for stream, pipe in (("out", job.proc.stdout), ("err", job.proc.stderr)):
            threading.Thread(target=self._pump, args=(job, stream, pipe), daemon=True).start()
        threading.Thread(target=self._wait, args=(job,), daemon=True).start()
        self.event("job", job=jid, status="running", name=job.name)
        self._save_state()
        return job

    def _pump(self, job, stream, pipe):
        for raw in iter(pipe.readline, b""):
            text = raw.decode("utf-8", "replace").rstrip("\r\n")
            if stream == "out" and text.startswith(SENTINEL):
                self._control(job, text[len(SENTINEL):])
            else:
                job.add(stream, text)

    def _control(self, job, payload):
        try:
            msg = json.loads(payload)
            op = msg.get("op")
            if op == "status":
                job.script_status = str(msg.get("text", ""))[:200]
            elif op == "notify":
                self.event("notify", job=job.id, title=str(msg.get("title", "XG Executor"))[:100],
                           text=str(msg.get("text", ""))[:500])
            elif op == "android":
                act = msg.get("action")
                if act in ("tap", "swipe", "back", "home", "recents", "notifications"):
                    self.event("android", job=job.id, action=act,
                               args={k: v for k, v in msg.items() if k in ("x", "y", "x2", "y2", "ms")})
                else:
                    job.add("err", "[xg] unknown android action %r" % act)
            elif op == "log":
                job.add("log", "[%s] %s" % (str(msg.get("level", "info")).upper(), msg.get("text", "")))
            else:
                job.add("err", "[xg] unknown API call %r" % op)
        except Exception as e:
            job.add("err", "[xg] bad API message: %s" % e)

    def _wait(self, job):
        rc = job.proc.wait()
        time.sleep(0.15)                      # let pumps drain
        job.exit_code, job.ended = rc, time.time()
        if job.stop_requested:
            job.status = "stopped"
        elif rc == 0:
            job.status = "finished"
        elif rc < 0:
            job.status = "killed"
            sig = signal.Signals(-rc).name if -rc in [s.value for s in signal.Signals] else str(-rc)
            job.add("err", "[xg] job was terminated by signal %s. Android may have killed the process "
                    "(battery optimization / phantom process killer). See README > Background execution." % sig)
        else:
            job.status = "failed"
        job.add("sys", "[xg] job %s %s (exit %s, %.1fs)" % (job.id, job.status, rc, job.ended - job.started))
        self.event("job", job=job.id, status=job.status, name=job.name, exit_code=rc)
        self._save_state()

    def stop(self, jid):
        job = self.jobs.get(str(jid))
        if not job:
            raise KeyError("no such job")
        if job.status not in ("running", "starting"):
            return job
        job.stop_requested = True
        try:
            os.killpg(job.proc.pid, signal.SIGTERM)
        except ProcessLookupError:
            return job
        def reaper():
            try:
                job.proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(job.proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
        threading.Thread(target=reaper, daemon=True).start()
        return job

    def stop_all(self):
        for j in list(self.jobs.values()):
            if j.status == "running":
                self.stop(j.id)

    # ---- script files
    @staticmethod
    def safe_name(name):
        base = os.path.basename(str(name))
        if not base or base.startswith(".") or base != name or not base.lower().endswith((".py", ".lua")):
            raise ValueError("invalid script name (use name.py or name.lua, no paths)")
        return base

    def handle(self, req):
        op = req.get("op")
        if op == "ping":
            return {"engine": "xg", "version": "1.0", "uptime": round(time.time() - self.started, 1),
                    "python": sys.version.split()[0], "lua": bool(find_runtime("lua")),
                    "pid": os.getpid(), "running": sum(j.status == "running" for j in self.jobs.values())}
        if op == "exec":
            j = self.start(req.get("lang", "python"), req.get("code", ""), req.get("name"), bool(req.get("background")))
            return {"job": j.id}
        if op == "stop":
            return {"job": self.stop(req["job"]).info()}
        if op == "stop_all":
            self.stop_all(); return {}
        if op == "jobs":
            return {"jobs": [j.info() for j in self.jobs.values()]}
        if op == "output":
            j = self.jobs.get(str(req.get("job")))
            if not j:
                raise KeyError("no such job")
            since = int(req.get("since", 0))
            with j.lock:
                lines = [[s, st, t] for s, st, t in j.lines if s > since]
            return {"lines": lines, "info": j.info(), "seq": j.seq}
        if op == "events":
            since = int(req.get("since", 0))
            with self.lock:
                evs = [e for e in self.events if e["seq"] > since]
            return {"events": evs, "seq": self.ev_seq}
        if op == "list_scripts":
            return {"scripts": sorted(f for f in os.listdir(SCRIPTS) if f.lower().endswith((".py", ".lua")))}
        if op == "save":
            n = self.safe_name(req.get("name"))
            with open(os.path.join(SCRIPTS, n), "w") as f:
                f.write(req.get("code", ""))
            return {"name": n}
        if op == "load":
            n = self.safe_name(req.get("name"))
            return {"name": n, "code": open(os.path.join(SCRIPTS, n)).read()}
        if op == "delete":
            os.remove(os.path.join(SCRIPTS, self.safe_name(req.get("name")))); return {}
        if op == "clear_finished":
            for k in [k for k, j in self.jobs.items() if j.status not in ("running", "starting")]:
                del self.jobs[k]
            self._save_state(); return {}
        raise ValueError("unknown op %r" % op)


class Handler(socketserver.StreamRequestHandler):
    def handle(self):
        eng, token = self.server.engine, self.server.token
        self.request.settimeout(30)
        try:
            while True:
                line = self.rfile.readline(MAX_REQ + 1)
                if not line:
                    return
                if len(line) > MAX_REQ:
                    return
                try:
                    req = json.loads(line)
                    if not isinstance(req, dict):
                        raise ValueError("request must be an object")
                    supplied = str(req.get("token", ""))
                    if not hmac.compare_digest(supplied.encode(), token.encode()):
                        self.wfile.write(b'{"ok":false,"error":"unauthorized"}\n')
                        return                      # drop connection on bad token
                    res = eng.handle(req)
                    out = {"ok": True, **res}
                except Exception as e:
                    out = {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}
                    if os.environ.get("XG_DEBUG"):
                        traceback.print_exc()
                self.wfile.write((json.dumps(out) + "\n").encode())
        except (socket.timeout, ConnectionError):
            return


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def main():
    token = ensure_home()
    eng = Engine()
    srv = Server((HOST, PORT), Handler)       # loopback only, never 0.0.0.0
    srv.engine, srv.token = eng, token
    def bye(*_):
        eng.stop_all()
        threading.Thread(target=srv.shutdown, daemon=True).start()
    signal.signal(signal.SIGTERM, bye)
    signal.signal(signal.SIGINT, bye)
    print("XG engine listening on %s:%d (token in %s)" % (HOST, PORT, TOKEN_FILE), flush=True)
    srv.serve_forever()
    print("XG engine stopped", flush=True)


if __name__ == "__main__":
    main()
