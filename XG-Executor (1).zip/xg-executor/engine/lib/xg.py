"""XG API for Python scripts:  import xg
All calls talk to the XG engine through stdout; no network, no extra deps."""
import json, os, sys, time

_S = "\x1eXG\x1e"
job_id = os.environ.get("XG_JOB_ID", "")
job_name = os.environ.get("XG_JOB_NAME", "")


def _send(**msg):
    sys.stdout.write(_S + json.dumps(msg) + "\n")
    sys.stdout.flush()


def log(text, level="info"):
    """Write a leveled log line to the console (level: info, warn, error, debug)."""
    _send(op="log", level=level, text=str(text))

def status(text):
    """Set the status text shown next to this job in the Jobs list."""
    _send(op="status", text=str(text))

def notify(text, title="XG Executor"):
    """Show an Android notification (via the XG app)."""
    _send(op="notify", title=str(title), text=str(text))

def sleep(seconds):
    time.sleep(seconds)

def every(seconds, fn, count=None):
    """Call fn() every `seconds`; stops after `count` calls (None = until stopped)."""
    n = 0
    while count is None or n < count:
        fn(); n += 1
        if count is None or n < count:
            time.sleep(seconds)

def after(seconds, fn):
    """Block `seconds`, then call fn()."""
    time.sleep(seconds); return fn()

class android:
    """Needs the XG Accessibility Service enabled in Android settings.
    Acts only in the foreground app, via standard accessibility gestures."""
    @staticmethod
    def tap(x, y): _send(op="android", action="tap", x=x, y=y)
    @staticmethod
    def swipe(x, y, x2, y2, ms=300): _send(op="android", action="swipe", x=x, y=y, x2=x2, y2=y2, ms=ms)
    @staticmethod
    def back(): _send(op="android", action="back")
    @staticmethod
    def home(): _send(op="android", action="home")
    @staticmethod
    def recents(): _send(op="android", action="recents")
    @staticmethod
    def notifications(): _send(op="android", action="notifications")
