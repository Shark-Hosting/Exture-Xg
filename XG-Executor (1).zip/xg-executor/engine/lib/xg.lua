-- XG API for Lua 5.4:  local xg = require("xg")
local M = {}
local S = "\30XG\30"
M.job_id = os.getenv("XG_JOB_ID") or ""

local function esc(s)
  s = tostring(s)
  return (s:gsub('[%c"\\]', function(c)
    local m = {['"']='\\"', ['\\']='\\\\', ['\n']='\\n', ['\r']='\\r', ['\t']='\\t'}
    return m[c] or string.format("\\u%04x", c:byte())
  end))
end
local function send(t)
  local parts = {}
  for k, v in pairs(t) do
    if type(v) == "number" then parts[#parts+1] = string.format('"%s":%s', k, tostring(v))
    else parts[#parts+1] = string.format('"%s":"%s"', k, esc(v)) end
  end
  io.stdout:write(S .. "{" .. table.concat(parts, ",") .. "}\n")
  io.stdout:flush()
end

function M.log(text, level) send{op="log", level=level or "info", text=text} end
function M.status(text) send{op="status", text=text} end
function M.notify(text, title) send{op="notify", title=title or "XG Executor", text=text} end
function M.sleep(seconds) os.execute("sleep " .. tonumber(seconds)) end
function M.every(seconds, fn, count)
  local n = 0
  while not count or n < count do
    fn(); n = n + 1
    if not count or n < count then M.sleep(seconds) end
  end
end
function M.after(seconds, fn) M.sleep(seconds); return fn() end

M.android = {
  tap = function(x, y) send{op="android", action="tap", x=x, y=y} end,
  swipe = function(x, y, x2, y2, ms) send{op="android", action="swipe", x=x, y=y, x2=x2, y2=y2, ms=ms or 300} end,
  back = function() send{op="android", action="back"} end,
  home = function() send{op="android", action="home"} end,
  recents = function() send{op="android", action="recents"} end,
  notifications = function() send{op="android", action="notifications"} end,
}
return M
