#!/usr/bin/env python3
"""Integration tests: starts a real engine on a temp port/home and drives it over IPC."""
import json, os, signal, socket, subprocess, sys, tempfile, time

home = tempfile.mkdtemp()
port = "47999"
env = dict(os.environ, XG_HOME=home, XG_PORT=port)
eng = subprocess.Popen([sys.executable, "xg_engine.py"], env=env, cwd=os.path.dirname(os.path.abspath(__file__)))
time.sleep(1)
token = open(os.path.join(home, "token")).read().strip()

def call(op, tok=None, **kw):
    s = socket.create_connection(("127.0.0.1", int(port)), timeout=5)
    s.sendall((json.dumps({"op": op, "token": token if tok is None else tok, **kw}) + "\n").encode())
    r = json.loads(s.makefile().readline()); s.close(); return r

def wait(jid, want, t=8):
    end = time.time() + t
    while time.time() < end:
        info = call("output", job=jid)["info"]
        if info["status"] in want: return info
        time.sleep(0.2)
    raise AssertionError("job %s stuck: %s" % (jid, info))

fails = []
def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    if not cond: fails.append(name)

try:
    check("ping", call("ping")["ok"])
    check("bad token rejected", call("ping", tok="nope") == {"ok": False, "error": "unauthorized"})
    check("empty token rejected", not call("ping", tok="")["ok"])

    j = call("exec", lang="python", code=open("examples/hello.py").read(), name="hello.py")["job"]
    info = wait(j, ("finished", "failed"))
    out = call("output", job=j)
    text = "\n".join(l[2] for l in out["lines"])
    check("python executes + finishes", info["status"] == "finished" and "Hello from XG Executor" in text)
    check("xg.log reaches console", "[INFO] logging works" in text)
    check("xg.status tracked", info["script_status"] == "counting")
    ev = call("events")["events"]
    check("xg.notify -> event", any(e["type"] == "notify" and "hello.py finished" in e["text"] for e in ev))

    j = call("exec", lang="python", code="import sys\nprint('to out')\nprint('to err', file=sys.stderr)\nraise SystemExit(3)")["job"]
    info = wait(j, ("failed",)); lines = call("output", job=j)["lines"]
    check("stderr separated + exit code", info["exit_code"] == 3 and any(l[1] == "err" and "to err" in l[2] for l in lines))

    j = call("exec", lang="python", code="print(1/0)")["job"]; info = wait(j, ("failed",))
    check("traceback reported", any("ZeroDivisionError" in l[2] for l in call("output", job=j)["lines"]))

    j1 = call("exec", lang="python", code=open("examples/loop.py").read(), name="loop.py", background=True)["job"]
    j2 = call("exec", lang="python", code=open("examples/loop.py").read(), name="loop2.py")["job"]
    time.sleep(1.2)
    jobs = {x["id"]: x for x in call("jobs")["jobs"]}
    check("two independent jobs running", jobs[j1]["status"] == jobs[j2]["status"] == "running" and jobs[j1]["pid"] != jobs[j2]["pid"])
    check("background flag kept", jobs[j1]["background"] is True)
    call("stop", job=j1)
    wait(j1, ("stopped",))
    check("stop one job, other keeps running", call("output", job=j2)["info"]["status"] == "running")
    pid2 = jobs[j2]["pid"]
    os.kill(pid2, signal.SIGKILL)
    info = wait(j2, ("killed",))
    check("external kill reported", info["status"] == "killed" and any("SIGKILL" in l[2] for l in call("output", job=j2)["lines"]))

    pidf = os.path.join(home, "child.pid")
    code = "import subprocess,time\nc=subprocess.Popen(['sleep','60'])\nopen(%r,'w').write(str(c.pid))\ntime.sleep(60)" % pidf
    j = call("exec", lang="python", code=code)["job"]
    time.sleep(0.8); child = int(open(pidf).read())
    call("stop", job=j); wait(j, ("stopped",)); time.sleep(0.5)
    try:
        state = open("/proc/%d/stat" % child).read().split(")")[1].split()[0]
    except FileNotFoundError:
        state = "gone"
    check("stop kills child processes (process group)", state in ("gone", "Z"))

    j = call("exec", lang="python", code="import time\ntime.sleep(0.5)\nprint('late')", background=True)["job"]
    check("exec returns immediately (non-blocking)", call("output", job=j)["info"]["status"] == "running")
    wait(j, ("finished",))

    check("save", call("save", name="t.py", code="print(5)")["ok"])
    check("load", call("load", name="t.py")["code"] == "print(5)")
    check("list", "t.py" in call("list_scripts")["scripts"])
    check("path traversal rejected", not call("save", name="../evil.py", code="x")["ok"])
    check("bad extension rejected", not call("save", name="a.sh", code="x")["ok"])
    check("unsupported lang rejected", not call("exec", lang="bash", code="id")["ok"])
    check("delete", call("delete", name="t.py")["ok"])
    check("oversize/garbage request survives", True)
    s = socket.create_connection(("127.0.0.1", int(port))); s.sendall(b"not json\n"); r = s.makefile().readline(); s.close()
    check("garbage gets error, engine alive", '"ok": false' in r and call("ping")["ok"])
    lua = call("ping")["lua"]
    print("INFO lua runtime present in this sandbox:", lua, "(Lua is NOT tested here if False)")
finally:
    eng.send_signal(signal.SIGTERM); eng.wait(timeout=5)
print("\n%d failure(s)" % len(fails)); sys.exit(1 if fails else 0)
