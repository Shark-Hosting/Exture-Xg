#!/data/data/com.termux/files/usr/bin/bash
# XG Executor engine installer (run inside Termux, from this directory).
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"

echo "[1/4] Installing runtimes (python, lua54)…"
pkg update -y
pkg install -y python lua54

echo "[2/4] Creating ~/.xg and the auth token…"
mkdir -p "$HOME/.xg/scripts"; chmod 700 "$HOME/.xg"
if [ ! -f "$HOME/.xg/token" ]; then
  ( umask 077; python3 -c 'import secrets;print(secrets.token_hex(16))' > "$HOME/.xg/token" )
fi
cp -n "$DIR"/examples/* "$HOME/.xg/scripts/" 2>/dev/null || true

echo "[3/4] Installing the 'xg' command…"
cat > "$PREFIX/bin/xg" <<WRAP
#!/data/data/com.termux/files/usr/bin/bash
XG_DIR="$DIR"
XG_HOME="\$HOME/.xg"
PIDF="\$XG_HOME/engine.pid"
running() { [ -f "\$PIDF" ] && kill -0 "\$(cat "\$PIDF")" 2>/dev/null; }
case "\$1" in
  start)
    if running; then echo "XG engine already running (pid \$(cat "\$PIDF"))"; exit 0; fi
    command -v termux-wake-lock >/dev/null && termux-wake-lock
    cd "\$XG_DIR" && nohup setsid python3 xg_engine.py >> "\$XG_HOME/engine.log" 2>&1 &
    echo \$! > "\$PIDF"; sleep 1
    if running; then echo "XG engine started (pid \$(cat "\$PIDF")), log: \$XG_HOME/engine.log"
    else echo "Engine failed to start, see: xg logs"; exit 1; fi ;;
  stop)
    if running; then kill "\$(cat "\$PIDF")"; sleep 1; echo "XG engine stopped"
    else echo "XG engine is not running"; fi
    rm -f "\$PIDF"; command -v termux-wake-unlock >/dev/null && termux-wake-unlock ;;
  restart) "\$0" stop; "\$0" start ;;
  status) if running; then echo "running (pid \$(cat "\$PIDF"))"; else echo "stopped"; fi ;;
  token) cat "\$XG_HOME/token"; echo ;;
  logs) tail -n 50 "\$XG_HOME/engine.log" ;;
  test) cd "\$XG_DIR" && python3 test_engine.py ;;
  *) echo "usage: xg {start|stop|restart|status|token|logs|test}"; exit 1 ;;
esac
WRAP
chmod +x "$PREFIX/bin/xg"

echo "[4/4] Self-test…"
cd "$DIR" && python3 test_engine.py | tail -n 4
command -v lua5.4 >/dev/null || command -v lua >/dev/null || echo "WARNING: Lua not found on PATH"
echo
echo "Done. Next:  xg start   then   xg token   (paste the token into the XG app)"
